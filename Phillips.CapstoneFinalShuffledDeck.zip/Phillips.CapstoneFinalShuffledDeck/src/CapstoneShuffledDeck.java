import javax.swing.JOptionPane;
import java.util.Random;

public class CapstoneShuffledDeck {

    private String[] ranks;
    private String[] suits;
    private String[] deck;

    public static void main(String[] args) {
        new CapstoneShuffledDeck().run();
    }


    // Main program flow

    public void run() {
        showWelcomeMessage();
        ranks = promptForValues("Enter the ranks (comma-separated):");
        suits = promptForValues("Enter the suits (comma-separated):");

        deck = buildDeck(ranks, suits);
        String[] shuffledDeck = shuffle(deck);

        showDeck("Your shuffled deck:", shuffledDeck);
    }


    // User Interaction

    private void showWelcomeMessage() {
        JOptionPane.showMessageDialog(null,
            "Welcome! This program will create and shuffle a custom deck of cards.");
    }

    private String[] promptForValues(String message) {
        String input = JOptionPane.showInputDialog(message);
        return input.replace(" ", "").split(",");
    }


    // Deck Creation

    private String[] buildDeck(String[] ranks, String[] suits) {
        int totalCards = ranks.length * suits.length;
        String[] newDeck = new String[totalCards];

        int index = 0;
        for (String rank : ranks) {
            for (String suit : suits) {
                newDeck[index++] = rank + " of " + suit;
            }
        }
        return newDeck;
    }


    // Shuffle
    
    private String[] shuffle(String[] originalDeck) {
        String[] shuffled = originalDeck.clone();
        Random random = new Random();

        for (int i = shuffled.length - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            swap(shuffled, i, j);
        }
        return shuffled;
    }

    private void swap(String[] array, int i, int j) {
        String temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }


    // Display

    private void showDeck(String title, String[] deckToShow) {
        StringBuilder output = new StringBuilder(title + "\n\n");

        for (String card : deckToShow) {
            output.append(card).append("\n");
        }

        JOptionPane.showMessageDialog(null, output.toString());
    }
}
