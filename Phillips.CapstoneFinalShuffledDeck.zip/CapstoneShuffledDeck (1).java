
//  yourLastName.CapstoneShuffledDeck
//  Creates a deck of cards and shuffles it


import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Collections;

public class  CapstoneShuffledDeck {

    public static void main(String[] args) {

        // Welcome message
        JOptionPane.showMessageDialog(null,
            "Welcome! This program will create and shuffle a custom deck of cards.");

        // Get ranks from user
        ArrayList<String> ranks = getRanksFromUser();

        // Get suits from user
        ArrayList<String> suits = getSuitsFromUser();

        // Create deck
        ArrayList<String> deck = createDeck(ranks, suits);

        // Shuffle deck
        ArrayList<String> shuffledDeck = shuffleDeck(deck);

        // Display shuffled deck
        displayShuffledDeck(shuffledDeck);
    }

  
    // Ask user to enter ranks for the deck

    public static ArrayList<String> getRanksFromUser() {

        String input = JOptionPane.showInputDialog(
            "Enter the ranks for your deck (comma-separated):");

        String[] parts = input.split(",");

        ArrayList<String> ranks = new ArrayList<>();

        for (String r : parts) {
            ranks.add(r.trim());
        }

        return ranks;
    }

    // Ask user to enter suits for the deck

    public static ArrayList<String> getSuitsFromUser() {

        String input = JOptionPane.showInputDialog(
            "Enter the suits for your deck (comma-separated):");

        String[] parts = input.split(",");

        ArrayList<String> suits = new ArrayList<>();

        for (String s : parts) {
            suits.add(s.trim());
        }

        return suits;
    }

    // Create the deck by combining every rank with every suit

    public static ArrayList<String> createDeck(ArrayList<String> ranks,
                                               ArrayList<String> suits) {

        ArrayList<String> deck = new ArrayList<>();

        for (String rank : ranks) {
            for (String suit : suits) {
                deck.add(rank + " of " + suit);
            }
        }

        return deck;
    }

 
    // Shuffle the deck and return the shuffled deck

    public static ArrayList<String> shuffleDeck(ArrayList<String> deck) {

        // Make a copy so the original deck is preserved
        ArrayList<String> shuffled = new ArrayList<>(deck);

        // Shuffle the copy
        Collections.shuffle(shuffled);

        return shuffled;   // required by assignment
    }


    // Display the shuffled deck to the user

    public static void displayShuffledDeck(ArrayList<String> deck) {

        StringBuilder sb = new StringBuilder();

        sb.append("Your shuffled deck contains ")
          .append(deck.size())
          .append(" cards:\n\n");

        for (String card : deck) {
            sb.append(card).append("\n");
        }

        JOptionPane.showMessageDialog(null, sb.toString());
    }
}
