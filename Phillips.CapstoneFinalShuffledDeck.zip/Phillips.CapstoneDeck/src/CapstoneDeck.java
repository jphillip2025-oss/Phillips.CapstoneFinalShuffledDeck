
//  yourLastName.CapstoneDeck
//  Completed code for creating one deck of playing cards


import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.Collections;

public class CapstoneDeck {

    public static void main(String[] args) {

        // Welcome message
        JOptionPane.showMessageDialog(null,
            "Welcome! This program will create and shuffle a custom deck of cards.");

        // Get ranks from user
        ArrayList<String> ranks = getRanksFromUser();

        // Get suits from user
        ArrayList<String> suits = getSuitsFromUser();

        // Create deck
        ArrayList<String> deck = createDeck(ranks, suits);

        // Shuffle deck
        shuffleDeck(deck);

        // Display deck
        displayDeck(deck);
    }

   
    // Ask user to enter ranks for the deck
  
    public static ArrayList<String> getRanksFromUser() {

        String input = JOptionPane.showInputDialog(
            "Enter the ranks for your deck (comma-separated):");

        // Split into list
        String[] parts = input.split(",");

        ArrayList<String> ranks = new ArrayList<>();

        for (String r : parts) {
            ranks.add(r.trim());
        }

        return ranks;
    }


    // Ask user to enter suits for the deck

    public static ArrayList<String> getSuitsFromUser() {

        String input = JOptionPane.showInputDialog(
            "Enter the suits for your deck (comma-separated):");

        // Split into list
        String[] parts = input.split(",");

        ArrayList<String> suits = new ArrayList<>();

        for (String s : parts) {
            suits.add(s.trim());
        }

        return suits;
    }

  
    // Create the deck by combining every rank with every suit

    public static ArrayList<String> createDeck(ArrayList<String> ranks,
                                               ArrayList<String> suits) {

        ArrayList<String> deck = new ArrayList<>();

        for (String rank : ranks) {
            for (String suit : suits) {
                deck.add(rank + " of " + suit);
            }
        }

        return deck;
    }


    // Shuffle the deck into random order

    public static void shuffleDeck(ArrayList<String> deck) {
        Collections.shuffle(deck);
    }


    // Display the shuffled deck to the user
  
    public static void displayDeck(ArrayList<String> deck) {

        StringBuilder sb = new StringBuilder();

        sb.append("Your shuffled deck contains ")
          .append(deck.size())
          .append(" cards:\n\n");

        for (String card : deck) {
            sb.append(card).append("\n");
        }

        JOptionPane.showMessageDialog(null, sb.toString());
    }
}
