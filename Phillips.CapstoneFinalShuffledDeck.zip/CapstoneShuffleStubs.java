
//  Phillips.CapstoneShuffleStubs
//  Commented stubs for shuffling a deck of playing cards


import javax.swing.JOptionPane;
import java.util.ArrayList;

public class CapstoneShuffleStubs {

    public static void main(String[] args) {

        // Stub: Welcome message
        JOptionPane.showMessageDialog(null,
            "This program will shuffle a deck of playing cards.");

        // Stub: Get an existing deck (placeholder)
        ArrayList<String> deck = getDeck();

        // Stub: Shuffle the deck
        shuffleDeck(deck);

        // Stub: Display shuffled deck
        displayShuffledDeck(deck);
    }

   
    // Stub: Method to retrieve or create a deck of cards
  
    public static ArrayList<String> getDeck() {

        // Stub: Retrieve deck from Part 1
        // Stub: Or create a sample deck for testing
        // Stub: Return placeholder deck

        return new ArrayList<String>();  // placeholder
    }

  
    // Stub: Method to shuffle the deck

    public static void shuffleDeck(ArrayList<String> deck) {

        // Stub: Implement shuffle algorithm here
        // Stub: Use built-in shuffle or custom algorithm
        // Stub: Ensure deck contains all cards exactly once
    }


    // Stub: Method to display the shuffled deck

    public static void displayShuffledDeck(ArrayList<String> deck) {

        // Stub: Build string of shuffled cards
        // Stub: Display using JOptionPane
    }
}
